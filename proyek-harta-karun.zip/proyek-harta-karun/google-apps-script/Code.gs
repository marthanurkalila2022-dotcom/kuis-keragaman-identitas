/**
 * Backend Google Apps Script untuk aplikasi
 * "Petualangan Harta Karun Keragaman" — SD Negeri 1 Sidorejo.
 *
 * FUNGSI:
 *  - doPost(e): menerima hasil kuis dari aplikasi dan menyimpannya sebagai baris baru.
 *  - doGet(e) : mengirim semua hasil kuis (untuk Papan Peringkat / Buku Catatan Penjelajah gabungan).
 *
 * CARA PASANG:
 *  1. Buat Google Sheet baru (boleh diberi nama "Hasil Kuis Keragaman").
 *  2. Buka menu Extensions → Apps Script.
 *  3. Hapus semua kode contoh di editor, lalu tempel (paste) seluruh isi file ini.
 *  4. Klik Deploy → New deployment.
 *     - Pilih jenis (type): "Web app".
 *     - Execute as: "Me".
 *     - Who has access: "Anyone".
 *  5. Klik Deploy, lalu izinkan (Authorize) akses saat diminta.
 *  6. Salin URL Web App yang muncul (diakhiri /exec), lalu tempel ke kolom
 *     "URL Google Apps Script" pada Panel Guru di aplikasi kuis.
 *  7. Setiap kali ada perubahan pada file ini, buat "New deployment" lagi
 *     (atau gunakan "Manage deployments" → edit versi) agar perubahan aktif.
 */

function doPost(e) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();

  if (sheet.getLastRow() === 0) {
    sheet.appendRow([
      "Tanggal", "Nama Penjelajah", "Skor", "Skor Maksimal",
      "Rintangan Sempurna", "Total Rintangan", "Waktu (detik)"
    ]);
  }

  var data = JSON.parse(e.postData.contents);

  sheet.appendRow([
    data.date ? new Date(data.date) : new Date(),
    data.name || "(tanpa nama)",
    data.score || 0,
    data.maxScore || 0,
    data.correctCount || 0,
    data.total || 0,
    data.timeTaken || 0
  ]);

  return ContentService
    .createTextOutput(JSON.stringify({ status: "ok" }))
    .setMimeType(ContentService.MimeType.JSON);
}

function doGet(e) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  var values = sheet.getDataRange().getValues();
  var rows = values.slice(1); // lewati baris judul

  var results = rows
    .filter(function (r) { return r[1] && r[1] !== ""; })
    .map(function (r) {
      return {
        date: r[0],
        name: r[1],
        score: r[2],
        maxScore: r[3],
        correctCount: r[4],
        total: r[5],
        timeTaken: r[6]
      };
    });

  return ContentService
    .createTextOutput(JSON.stringify(results))
    .setMimeType(ContentService.MimeType.JSON);
}
