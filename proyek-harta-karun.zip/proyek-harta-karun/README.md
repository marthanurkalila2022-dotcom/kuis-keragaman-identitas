# 🗺️ Petualangan Harta Karun Keragaman

Aplikasi kuis interaktif Pendidikan Pancasila — materi **Keragaman Identitas** — untuk siswa
kelas 3 SD Negeri 1 Sidorejo, Pangkalan Bun. Dikemas sebagai petualangan mencari harta karun
dengan 10 rintangan (soal): gerbang teka-teki (pilihan ganda), jembatan jodoh (menjodohkan),
dan tangga runtunan (mengurutkan).

## Isi paket ini

```
index.html                         → aplikasi kuis (file utama, buka langsung di browser)
google-apps-script/Code.gs         → kode backend untuk menyimpan hasil ke Google Sheet
google-apps-script/appsscript.json → berkas konfigurasi Apps Script
.github/workflows/deploy-pages.yml → otomatis menerbitkan situs ke GitHub Pages
.gitignore
README.md                          → berkas ini
```

## Fitur

- 10 soal (6 pilihan ganda, 2 menjodohkan, 2 mengurutkan) tentang Keragaman Identitas.
- Login siswa (nama) & login Guru/Admin (kata sandi bawaan: `guru123`).
- Panel Guru untuk menambah/mengubah/menghapus soal, mengatur pengacakan soal, dan waktu per soal.
- Mode petualangan: peta pulau rintangan, waktu (timer) per soal, dan peti harta karun di akhir.
- Suara pemandu "Pak Surya" (Web Speech API, nada rendah agar terdengar seperti suara laki-laki bass).
- Hasil kuis tersimpan otomatis secara lokal (localStorage), dan — jika dihubungkan —
  otomatis terkirim & tersinkron ke **Google Sheet**, sehingga Buku Catatan Penjelawah
  (papan peringkat) bisa menampilkan hasil semua siswa dari perangkat berbeda.

---

## 1) Menjalankan langsung (tanpa GitHub)

Cukup buka file `index.html` dua kali klik di komputer, atau upload ke Google Drive dan buka
dengan browser. Semua fitur kuis, panel guru, dan penyimpanan lokal langsung berfungsi.

---

## 2) Menghubungkan ke Google Sheet (hasil kuis otomatis tersimpan)

1. Buka [Google Sheets](https://sheets.google.com) → buat spreadsheet baru, beri nama misalnya
   **"Hasil Kuis Keragaman"**.
2. Klik menu **Extensions → Apps Script**.
3. Hapus kode contoh (`myFunction`) yang ada, lalu salin-tempel seluruh isi file
   `google-apps-script/Code.gs` dari paket ini ke editor tersebut.
4. Klik **Deploy → New deployment**.
   - Klik ikon gerigi ⚙️ di samping "Select type", pilih **Web app**.
   - **Execute as**: `Me`.
   - **Who has access**: `Anyone`.
   - Klik **Deploy**, lalu klik **Authorize access** dan ikuti langkah izin akun Google.
5. Salin URL yang muncul (diakhiri `/exec`).
6. Buka aplikasi kuis → **Login Guru** (`guru123`) → tab **Pengaturan** → tempel URL tadi ke
   kolom "URL Google Apps Script" → klik **Simpan Pengaturan**.
7. Selesai! Setiap siswa yang menyelesaikan kuis, hasilnya otomatis tersimpan sebagai baris baru
   di Google Sheet, dan halaman **Buku Catatan Penjelajah** akan menampilkan peringkat gabungan
   dari semua perangkat yang terhubung ke Sheet yang sama.

> Catatan: jika suatu saat kode `Code.gs` diperbarui, buat ulang deployment lewat
> **Manage deployments → Edit → New version** agar perubahan aktif di URL yang sama.

---

## 3) Mengunggah ke GitHub & menerbitkan otomatis (GitHub Pages)

### A. Membuat repository dan mengunggah file

1. Buat repository baru di GitHub, misalnya `kuis-harta-karun-keragaman` (bisa Public atau Private,
   namun GitHub Pages gratis mensyaratkan Public kecuali punya GitHub Pro/Team).
2. Di komputer, buka folder proyek ini lewat terminal, lalu jalankan:

   ```bash
   git init
   git add .
   git commit -m "Petualangan harta karun keragaman identitas"
   git branch -M main
   git remote add origin https://github.com/USERNAME/kuis-harta-karun-keragaman.git
   git push -u origin main
   ```

   Ganti `USERNAME` dan nama repo sesuai punya Anda. (Atau, jika tidak terbiasa dengan git,
   file-file dalam paket ini juga bisa diunggah manual lewat tombol **"Add file → Upload files"**
   di halaman GitHub — pastikan struktur folder `.github/workflows/` ikut terunggah apa adanya.)

### B. Mengaktifkan penerbitan otomatis (GitHub Pages)

1. Buka repository di GitHub → **Settings → Pages**.
2. Pada bagian **Build and deployment → Source**, pilih **GitHub Actions**.
3. Workflow `.github/workflows/deploy-pages.yml` yang sudah disertakan akan otomatis berjalan
   setiap kali ada `push` ke branch `main`, dan menerbitkan `index.html` sebagai situs.
4. Setelah workflow selesai (lihat tab **Actions**), situs akan tersedia di:

   ```
   https://USERNAME.github.io/kuis-harta-karun-keragaman/
   ```

5. Setiap kali Anda mengubah soal lewat Panel Guru **di browser**, perubahan itu tersimpan di
   `localStorage` perangkat itu saja. Jika ingin soal baku yang sama untuk semua orang yang
   membuka situs GitHub Pages, ubah langsung larik `defaultQuestions()` pada `index.html`,
   lalu `git commit` & `git push` — GitHub Actions akan menerbitkan ulang otomatis.

---

## Mengubah kata sandi Admin/Guru

Buka `index.html`, cari baris berikut di bagian `<script>` paling atas, lalu ganti nilainya:

```js
var ADMIN_PASSWORD = "guru123";
```

---

## Struktur nilai

- Total 10 rintangan × 10 poin = 100 poin (keping emas).
- Soal menjodohkan & mengurutkan diberi nilai proporsional (poin dibagi sesuai jumlah pasangan/urutan yang benar).
- Jika waktu habis tanpa jawaban, poin rintangan tersebut = 0.

Selamat berpetualang mencari harta karun keragaman! 🏝️💰
